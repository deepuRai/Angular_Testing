import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {By} from '@angular/platform-browser'
import { VoterComponent } from './voter.component';

describe('VoterComponent', () => {
  let component: VoterComponent;
  let fixture: ComponentFixture<VoterComponent>;

  

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ VoterComponent ]
    })
    fixture = TestBed.createComponent(VoterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should render total votes', () => {
    component.othersVote = 10;
    component.myVote = 1;
    fixture.detectChanges();
    let de = fixture.debugElement.query(By.css('.vote-count'))
    let el :HTMLElement = de.nativeElement

    expect(el.innerText).toContain('11');

  });

  it('should highligh button if I upvoted', () => {
    component.myVote = 1;
    fixture.detectChanges();

    let de = fixture.debugElement.query(By.css('.glyphicon-menu-up'))
    
    expect(de.classes['highlighted']).toBeTruthy();
  });


  it('should increase total vote when click on upvote button', () => {
    let de = fixture.debugElement.query(By.css('.glyphicon-menu-up'))

    de.triggerEventHandler('click',null)

    expect(component.totalVotes).toBe(1)
    
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
